//: Playground - noun: a place where people can play

import UIKit

for num in 0...100 {
    
    if num % 5 == 0 { print("\(num) bingo!!!")
   
    } else if num % 2 == 0 { print("\(num) par!!!")
        
        
    } else if num % 1 == 0 { print("\(num) impar!!!")
    
    }; if num >= 30 && num <= 40 {print ("\(num)\t viva Swift !!!")
    }
    
    
}







